package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class CheckOut_POM {

	WebDriver driver=null;

	public CheckOut_POM(WebDriver driver){
		this.driver = driver;

	}

	By Click = By.xpath("//div[@class='inventory_list']//div[1]//div[3]//button[1]");
	By Click2=By.cssSelector("svg[class='svg-inline--fa fa-shopping-cart fa-w-18 fa-3x ']");
	By click3=By.cssSelector("a[class='btn_action checkout_button']");
	By ToConfirm=By.className("subheader");
	////
	By To_ContinueShopping=By.cssSelector("a[class='btn_secondary']");
	//////

	By firstname=By.id("first-name");
	By lastname=By.id("last-name");
	By zipcode=By.id("postal-code");
	By Continue= By.cssSelector("input[class='btn_primary cart_button']");
	//	By TocnfmContinue=By.className("cart_desc_label");

	//////
	By finish=By.xpath("//a[@class='btn_action cart_button']");
	/////
	//	By ToFinal_CONfirm=By.cssSelector("h3[data-test='error']");

	public void ClickBn(){
		driver.findElement(Click).click();
	}
	public void clickbn2(){

		driver.findElement(Click2).click();
	}
	public void clickbn3(){
		driver.findElement(click3).click();
	}

	public void ToConfirm(){
		try{
			driver.findElement(ToConfirm).getText();

		}catch(NoSuchElementException e){
			Assert.fail();
		}
	}
	public void SetFirstName(String name){

		driver.findElement(firstname).sendKeys(name);
	}
	public void SetLastName(String lstname){
		driver.findElement(lastname).sendKeys(lstname);
	}
	public void SetZipCode(String code){
		driver.findElement(zipcode).sendKeys(code);
	}

	public void ToContinue(){
		driver.findElement(Continue).click();

	}

	public void ToFinish(){
		driver.findElement(finish).click();

	}
	
	public void ContinueShopping_Button() {
		// TODO Auto-generated method stub
		driver.findElement(To_ContinueShopping).click();
	}




}
