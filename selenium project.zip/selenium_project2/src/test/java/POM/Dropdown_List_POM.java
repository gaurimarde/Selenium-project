package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdown_List_POM {
	WebDriver driver=null;
	public Dropdown_List_POM(WebDriver driver) {
		this.driver=driver;

	}
	
	By To_ShortList=By.cssSelector(".product_sort_container");
	 Select a =new Select(driver.findElement(To_ShortList));
	 
	By A_z =By.id("item_4_title_link");
   By Z_A=By.id("item_3_title_link");
	 
	 
	 public void ToClick(){
		 driver.findElement(To_ShortList).click();
	 }
	 public void A_to_z(){
			 a.selectByVisibleText("Name (A to Z)");
			 String aa=driver.findElement(A_z).getText();
			 System.out.println(aa);
	 }
	 
	 public void Z_to_A(){
			 a.selectByVisibleText("Name (Z to A)");
	 }
	 public void Price_low_to_High(){
		 a.selectByVisibleText("Price (low to high)");
	 }
	 public void Price_High_to_Low(){
		 a.selectByVisibleText("Price (high to low)");
	 }
}