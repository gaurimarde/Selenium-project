package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class LogOut_POM {
WebDriver driver=null;
	
	public LogOut_POM(WebDriver driver){
		this.driver=driver;
		
}
	By Step1=By.xpath("//button[normalize-space()='Open Menu']");
	By Step2=By.id("logout_sidebar_link");
	By ToConform=By.id("login_logo");

	public void Step1ToLogout(){
		 driver.findElement(Step1).click();
}
	public void Step2ToLogout(){
		
		driver.findElement(Step2).click();
	}
	public void ToConform(){
		
		try {
			driver.findElement(ToConform).getText();
		} catch (NoSuchElementException e) {
			Assert.fail();
		}
	}
}
