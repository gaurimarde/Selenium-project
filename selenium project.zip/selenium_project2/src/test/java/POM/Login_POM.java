package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Login_POM {

	WebDriver driver=null;

	public Login_POM(WebDriver driver) {
		this.driver=driver;

	}
	
	By Username= By.id("user-name");
	By Password=By.id("password");
	By Click=By.id("login-button");
	By inventory=By.className("product_label");
	
	public void SetUsername(String name){
		driver.findElement(Username).sendKeys(name);
		
	}
	
	public void SetPassword(String pass){
		driver.findElement(Password).sendKeys(pass);
	}
	
	public void ClickButton(){
		driver.findElement(Click).click();
	}
	
	public void GetTitle(){
		
		try{
			driver.findElement(inventory).getText();
		}catch(NoSuchElementException e){
			Assert.fail();
		}
	}
	
  }

