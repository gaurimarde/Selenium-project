package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Menu_Bar_POM {
	WebDriver driver=null;
	
	
	public Menu_Bar_POM(WebDriver driver){
		this.driver=driver;
	}
	
	
	By T0_Click=By.cssSelector("div[class='bm-burger-button'] button");
	By About=By.id("about_sidebar_link");
	
	
	public void Click(){
		driver.findElement(T0_Click).click();
	}
	
	public void About(){
		driver.findElement(About).click();
	}
}
