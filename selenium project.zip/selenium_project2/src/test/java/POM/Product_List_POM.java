package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Product_List_POM {
	WebDriver driver=null;

	public Product_List_POM(WebDriver driver) {
		this.driver=driver;
	}
	
//	By count=By.className("fa-layers-counter shopping_cart_badge");
	By count=By.cssSelector(".fa-layers-counter.shopping_cart_badge");
	
	By pr1=By.xpath("//div[@class='inventory_list']//div[1]//div[3]//button[1]");
	By pr2=By.xpath("//div[3]//div[3]//button[1]");
	By pr3=By.xpath("//div[6]//div[3]//button[1]");
	By pr4=By.xpath("//div[5]//div[3]//button[1]");
	
	
	public void Product1(){
		driver.findElement(pr1).click();
	}
	public void Product2(){
		driver.findElement(pr2).click();
	}
	public void Product3(){
		driver.findElement(pr3).click();
	}
	public void Product4(){
		driver.findElement(pr4).click();
	}
	public void Count(){
		driver.findElement(count);
	
	}
}
