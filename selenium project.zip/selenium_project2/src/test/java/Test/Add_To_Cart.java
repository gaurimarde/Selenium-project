package Test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import POM.LogOut_POM;
import POM.Login_POM;
import POM.Product_List_POM;

public class Add_To_Cart {
	
	WebDriver driver=null;
	

	@BeforeTest
	public void Lounch_Browser(){
		
		driver=new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/index.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
	}
	@BeforeMethod
	public void Login(){
     Login_POM login =new Login_POM(driver);
     
     login.SetUsername("standard_user");
     login.SetPassword("secret_sauce");
     login.ClickButton();
     login.GetTitle();

	}
	
  @Test(priority=1)
  public void Add_to_cart() {
	  
	 Product_List_POM add=new Product_List_POM(driver);
	 add.Product1();
	

	 String ct=driver.findElement(By.cssSelector(".fa-layers-counter.shopping_cart_badge")).getText();
	 
		int ct1=Integer.parseInt(ct);

		System.out.println(ct1);

		Assert.assertNotEquals(0, ct1);
	  
	  
  }
  @Test(priority=2)
  public void Add_to_cart_Multiple_Product() {
	  
		 Product_List_POM add=new Product_List_POM(driver);
		 add.Product1();
		 add.Product2();
		 add.Product3();
		 add.Product4();

		 String ct=driver.findElement(By.cssSelector(".fa-layers-counter.shopping_cart_badge")).getText();
		 
			int ct1=Integer.parseInt(ct);

			System.out.println(ct1);

			Assert.assertNotEquals(0, ct1);
		  
		  
	  }
  
  @AfterMethod
  public void LogOut(){
		LogOut_POM logout=new LogOut_POM(driver);
		logout.Step1ToLogout();
		logout.Step2ToLogout();
  }
		
  @AfterTest
	public void Close_Browser(){
		driver.quit();
	}
}
