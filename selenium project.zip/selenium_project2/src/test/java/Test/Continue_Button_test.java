package Test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import POM.CheckOut_POM;
import POM.LogOut_POM;
import POM.Login_POM;

public class Continue_Button_test {
	WebDriver driver=null;
	

	@BeforeTest
	public void Lounch_Browser(){
		
		driver=new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/index.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
	}

	@BeforeClass
	public void Login(){
		Login_POM login =new Login_POM(driver);

		login.SetUsername("standard_user");
		login.SetPassword("secret_sauce");
		login.ClickButton();
		login.GetTitle();

	}

	@BeforeMethod
	public void Checkout_Button_Functionality() {


		CheckOut_POM check =new CheckOut_POM(driver);
		check.ClickBn();
		check.clickbn2();
		check.clickbn3();
		check.ToConfirm();
	}

	@Test
	public void Continue_ButtonTest(){
		
		CheckOut_POM check =new CheckOut_POM(driver);
		check.SetFirstName("gauri");
		check.SetLastName("marde");
		check.SetZipCode("111111");
		check.ToContinue();
		try{
			
			driver.findElement(By.className("cart_desc_label"));
			
		}catch(NoSuchElementException e){
			Assert.fail();
		}
		
	}
	@AfterMethod
	  public void LogOut(){
			LogOut_POM logout=new LogOut_POM(driver);
			logout.Step1ToLogout();
			logout.Step2ToLogout();
			}
	 @AfterTest
		public void Close_Browser(){
			driver.quit();
		}
	
}
