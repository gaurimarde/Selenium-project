package Test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import POM.Login_POM;

public class Dropdown_List_Test {

	WebDriver driver=null;
	SoftAssert err=new SoftAssert();

	@BeforeTest
	public void Lounch_Browser(){

		driver=new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/index.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}
	@BeforeClass
	public void Login(){
		Login_POM login =new Login_POM(driver);

		login.SetUsername("standard_user");
		login.SetPassword("secret_sauce");
		login.ClickButton();
		login.GetTitle();

	}
	@Test(priority=1)
	public void DropdownTest_AtoZ() throws InterruptedException{

		//		Dropdown_List_POM list=new Dropdown_List_POM(driver);
		//		list.ToClick();
		Select dd= new Select(driver.findElement(By.className("product_sort_container")));

		dd.selectByValue("az");
		Thread.sleep(3000);
		try{
			driver.findElement(By.id("item_4_title_link"));
		}catch(NoSuchElementException e){
			err.assertAll();
		}

	}
	@Test(priority=2)
	public void DropdownTest_Z_A() throws InterruptedException{
		//		Dropdown_List_POM list=new Dropdown_List_POM(driver);
		//		list.ToClick();
		Select dd= new Select(driver.findElement(By.className("product_sort_container")));

		dd.selectByValue("az");
		Thread.sleep(3000);
		try{
			driver.findElement(By.id("item_3_title_link"));
		}catch(NoSuchElementException e){
			err.assertAll();
		}
	}
	@AfterTest
	public void Close_Browser(){
		driver.quit();
	}

}
