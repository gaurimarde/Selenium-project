package Test;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import POM.LogOut_POM;
import POM.Login_POM;

public class Login_Test {
	WebDriver driver=null;

	@BeforeTest
	public void Lounch_Browser(){

		driver=new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/index.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

	@Test
	public void Login(){
		Login_POM login =new Login_POM(driver);

		login.SetUsername("standard_user");
		login.SetPassword("secret_sauce");
		login.ClickButton();
		login.GetTitle();

	}
	@AfterMethod
	public void LogOut(){
		LogOut_POM logout=new LogOut_POM(driver);
		logout.Step1ToLogout();
		logout.Step2ToLogout();
	}
	@AfterTest
	public void Close_Browser(){
		driver.quit();
	}

}
