package Test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import POM.LogOut_POM;
import POM.Login_POM;

public class Login_Using_Multiple_ID_Password {

	
	WebDriver driver=null;

	@BeforeTest
	public void Lounch_Browser(){

		driver=new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/index.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}


	@Test(dataProvider="dtp")
	public void Login_Using_Multiple_ID_Password_Test(String name, String pass){
		Login_POM login =new Login_POM(driver);

		login.SetUsername(name);
		login.SetPassword(pass);
		login.ClickButton();
//		login.GetTitle();
		
		try{
			driver.findElement(By.className("product_label"));
		}catch(NoSuchElementException e){
			Assert.fail();

		}
	}
		

	
	@AfterMethod
	public void LogOut(){
		LogOut_POM logout=new LogOut_POM(driver);
		logout.Step1ToLogout();
		logout.Step2ToLogout();
	}
	@AfterTest
	public void Close_Browser(){
		driver.quit();
	}
	@DataProvider(name="dtp")
	String [][]CreatData(){

		String[][] data={
				{"standard_user","secret_sauce"},
//				{"locked_out_user","secret_sauce"},
				{"performance_glitch_user","secret_sauce"},
				{"problem_user","secret_sauce"},
//				{"gauri","secret_sauce"}

		};
		return data;
	}
}
