package Test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import POM.Login_POM;
import POM.Menu_Bar_POM;

public class Menu_Bar_Test {
	WebDriver driver=null;

	@BeforeTest
	public void Lounch_Browser(){

		driver=new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/index.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

	@BeforeClass
	public void Login(){
		Login_POM login =new Login_POM(driver);

		login.SetUsername("standard_user");
		login.SetPassword("secret_sauce");
		login.ClickButton();
		login.GetTitle();

	}

	@Test
	public void Menu_bar_Test(){

		Menu_Bar_POM click=new Menu_Bar_POM(driver);

		click.Click();
		click.About();
		try{
			driver.findElement(By.cssSelector("img[alt='Saucelabs'][src='/images/logo.svg']"));
		}catch(NoSuchElementException e){
			Assert.fail();
		}
	}


	@AfterTest
	public void Close_Browser(){
		driver.quit();
	}

}
